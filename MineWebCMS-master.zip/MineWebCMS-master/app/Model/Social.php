<?php

class Social extends AppModel {
}
