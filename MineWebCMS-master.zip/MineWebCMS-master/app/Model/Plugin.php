<?php

class Plugin extends AppModel
{
}
