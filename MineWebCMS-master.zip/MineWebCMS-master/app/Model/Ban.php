<?php

class Ban extends AppModel
{
}
